import image from '../assets/avatar-placeholder.webp';

export const AVATAR_PLACEHOLDER = image;
