export type Member = {
	name: string;
	role: string;
	image?: string;
};

export type Members = Member[];
